# OpenCW (OpenCatWeb)

OpenCW bridges **CatWeb** pages and Python. A page prints a command into the
Roblox console, OpenCW runs the matching Python function, and whatever the
function returns is pasted into that page's address bar and confirmed with
Enter - which is how a CatWeb browser tab receives data back.

It is a reworked sibling of ACWAPIC with a different API, a different wire
format, relative window coordinates, a log-file driver for Windows, and no
`keyboard` dependency (so it does not need root on Linux).

```
CatWeb page ──print("ocw::Ping hello")──► Roblox console
                                             │
                                    OpenCW reads the line
                                             │
                                    @opencw.command("Ping")
                                             │
        address bar ◄──"hub.opencw.rbx"──────┘
             │
        Enter = the page navigates
```

---

## Install

```powershell
cd $env:USERPROFILE\Downloads\OpenCW
python -m pip install -r requirements.txt
python main.py
```

`python main.py` loads `config.yaml`, launches or attaches to the client, and
listens for commands.

Handy check:

```powershell
python -m opencw doctor
```

It prints the active config file, driver, bound commands and which optional
packages are missing.

To see the end of the newest client log (useful while working out the marker):

```powershell
python -m opencw logs
```

---

## The wire format

A page sends a command by printing one line:

```
ocw::Ping hello from the hub
^^^^  ^^^^  ^^^^^^^^^^^^^^^^^
  |     |        payload (optional)
  |   command name, case-insensitive
prefix (`listen.prefix`)
```

CatWeb often prefixes page output with `[From wa.rbx/home]:`. OpenCW strips
that automatically and uses `wa.rbx/home` (or `wa.rbx` for tab lookup) as the
origin.

The reply is the handler's return value:

| Returned value | What OpenCW does |
| --- | --- |
| `None` | nothing; the page stays where it is |
| `"hub.opencw.rbx"` | focuses the originating tab, types the value into the address bar, presses Enter |
| any other object | converted to a string first |

The prefix and command names are entirely yours. Nothing in OpenCW expects the
ACWAPIC `Print-Log` style.

---

## Example

`main.py`:

```python
import opencw

@opencw.command("Ping")
def ping(payload: str):
    opencw.say(f"ping from the site: {payload!r}")
    return "hub.opencw.rbx"

@opencw.command("Log-Line")
def log_line(payload: str):
    opencw.say(payload)

@opencw.command("Status")
def status():
    return f"hub.opencw.rbx?commands={len(opencw.commands())}"

opencw.start()
```

A handler may take zero arguments or one `payload` argument. Exceptions are
caught and printed; they never kill the listener.

A fuller, runnable example lives in `demo.py`:

```powershell
python demo.py
```

It binds `Ping`, `Log-Line`, `Status`, `Tabs` and `Help`, which is a good
starting point to copy from.

---

## API

| Call | Purpose |
| --- | --- |
| `opencw.command(name)` | decorator that binds a function to a command |
| `opencw.start(quiet=False, driver=None)` | run the main loop (blocks) |
| `opencw.commands()` | copy of the bound command table |
| `opencw.say(text)` | timestamped user log line |
| `opencw.status(text)` | timestamped system log line |
| `opencw.push(tab, text)` | send text to a specific tab |
| `opencw.tab_of(domain)` | tab number currently showing a domain |
| `opencw.tabs()` | `{index: domain}` of the tabs OpenCW opened |
| `opencw.set(path, value)` | override a config value for this run only |
| `opencw.settings()` | deep copy of the active configuration |

---

## Platform switch

OpenCW chooses its platform scripts from a small file **inside the package**:

```
opencw/config.txt
```

```text
# LINUX?: yes   -> Linux scripts: Flatpak + Sober, console from stdout
# LINUX?: no    -> Windows scripts: Roblox client, console from the newest log
# LINUX?: auto  -> detect from the operating system
LINUX?: no
```

The bundled copy is set to `no` (Windows). Change it to `yes` for Linux, or
`auto` to let the operating system decide, then restart OpenCW.

The value is read once per process. `python -m opencw doctor` prints which
script set is active and where the decision came from. If the file is missing,
OpenCW auto-detects.

With `client.driver: auto`, the switch also selects the driver:

| Switch | Driver | Window title |
| --- | --- | --- |
| `yes` | `sober` | `Sober` |
| `no` | `log` | `Roblox` |
| `auto` | detected | detected |

---

## Drivers

`client.driver` decides where console lines come from.

### `sober` (Linux)

```yaml
client:
  driver: sober
  flatpak: "org.vinegarhq.Sober"
  place-id: 16855862021
  boot-domain: "boot.opencw.rbx"
```

Runs `flatpak run org.vinegarhq.Sober "roblox://placeId=...\&launchData=..."` and
streams its stdout. The Flatpak is updated by the user, not by OpenCW.

### `command` (any OS)

```yaml
client:
  driver: command
  command: ["my-launcher", "--follow-console"]
```

Any program that prints the game console to stdout works.

### `log` (Windows or any OS)

```yaml
client:
  driver: log
  log-glob: '%LOCALAPPDATA%\Roblox\logs\*.log'
  log-poll-seconds: 0.25
```

Follows the newest matching file, survives rotation, and skips content that was
already there when OpenCW started. Start Roblox and CatWeb yourself, then run
OpenCW.

Because the client is already running, the `log` driver works in **attach
mode**: `listen.require-boot` and `listen.manage-tabs` default to `false`, so
commands are accepted immediately and OpenCW never closes your existing tabs.
Replies go to the focused tab unless you set `listen.reply-target: fixed`.
A boot signal that was printed before OpenCW started is therefore harmless.

### `auto`

Follows `opencw/config.txt`: the Linux script set uses `sober`, the Windows
script set uses `log`. `command` is only chosen automatically when no log glob
is configured.

---

## Configuration

`config.yaml` sits next to the script. `OPENCW_CONFIG` may point at another
file. If no file exists, the bundled `config.fallback.yaml` is copied into the
working directory and OpenCW exits once so you can review it.

### `client`

| Key | Meaning |
| --- | --- |
| `driver` | `auto`, `sober`, `command` or `log` |
| `flatpak` | Sober application id |
| `place-id` | CatWeb place id |
| `command` | executable used by the `command` driver |
| `log-glob` | file pattern used by the `log` driver |
| `log-poll-seconds` | how often to poll the log file |
| `window-title` | window to find; `auto` tries `Sober` then `Roblox` |
| `window-timeout` | seconds to wait for it |
| `domains` | pages kept open, maximum 9 |
| `boot-domain` | first page loaded; prints the boot signal |

### `viewport`

| Key | Meaning |
| --- | --- |
| `position-x`, `position-y` | window position |
| `width`, `height` | window size |
| `address-x`, `address-y` | address bar offset **from the window's top-left** |
| `key-delay-ms` | pause between synthetic keys |
| `setup-delay-ms` | pause while opening/switching tabs |

If no window could be found, `address-x`/`address-y` are treated as absolute
screen coordinates instead. That makes OpenCW usable even without a window
backend, but relative offsets are the recommended setup.

### `listen`

| Key | Meaning |
| --- | --- |
| `marker` | only lines containing this string are examined |
| `prefix` | command prefix, default `ocw::` |
| `boot-signal` | text printed by the boot page; enables tabs and commands |
| `require-boot` | only accept commands after the boot signal (`auto` = only when OpenCW launched the client) |
| `manage-tabs` | open `client.domains` after boot (`auto` = only when OpenCW launched the client) |
| `reply-target` | `origin` (default) or `fixed` |
| `fixed-tab` | tab used when `reply-target` is `fixed` |
| `workers` | handler thread count |
| `idle-seconds` | anti-idle Escape presses; `0` disables |
| `ignore` | substrings hidden from the console |

### `logging`

| Key | Meaning |
| --- | --- |
| `colour` | ANSI colours |
| `show-game-lines` | print detected lines that are not commands |
| `show-unmatched` | print every raw line (debugging) |

---

## Setting up the client

1. Install Sober (Linux) or Roblox (Windows).
2. Put the page domains you want into `client.domains`.
3. Make the boot page print the boot signal once it is ready.
4. Point `client.boot-domain` at that page.
5. Run OpenCW and wait for `setting up N tab(s)`.

On Linux, X11 is recommended. Wayland compositors often refuse synthetic
input; `python -m opencw doctor` warns when it detects Wayland.

On Windows, if Roblox runs elevated, run OpenCW elevated too, otherwise the
keystrokes will be ignored. High-DPI scaling can shift coordinates - set the
display to 100% or adjust `viewport.address-x/y`.

### First-run checklist on Windows

The Windows player logs `print()` output with a different prefix than Sober.
If nothing is detected:

1. Set `logging.show-unmatched: true`.
2. Run OpenCW and look at the raw `GAME` lines while a page prints something.
3. Copy the part before your message into `listen.marker`.
4. Clear `listen.boot-signal` if the boot page does not send it, and use the
   text it actually prints instead.

`python -m opencw logs` prints the tail of the newest client log if you want to
inspect the format without starting OpenCW.

---

## Differences from ACWAPIC

- Package and API are renamed: `opencw`, `@opencw.command`, `opencw.start`,
  `opencw.say`, `opencw.push`, `opencw.set`.
- Commands use the `ocw::name payload` prefix instead of a bare `name payload`
  keyword, so normal game output cannot trigger a handler by accident.
- Address bar coordinates are relative to the window, not absolute.
- Reply routing defaults to the page that sent the command.
- Replies run through a queue, so handler threads never fight over the keyboard.
- Three drivers instead of one: Sober, arbitrary subprocess, log file.
- A package-level `config.txt` switch (`LINUX?: yes/no/auto`) selects the Linux
  or Windows script set before the driver is chosen.
- `pyautogui` replaces `keyboard`, so no `/dev/input` or root requirement.
- Window placement tries `pywinctl`, then `PyGetWindow` (bundled with pyautogui).
- Missing dependencies degrade into warnings instead of failing at import.
- `python -m opencw doctor` for diagnostics.

---

## Troubleshooting

**Nothing is detected.** Check `listen.marker` against the raw lines with
`logging.show-unmatched: true`. On the Windows client the marker is usually not
`[FLog::CreatorOutput]`.

**The log driver is reading, but nothing happens.** Two things must be true: a
page must actually print `ocw::...`, and OpenCW must not still be waiting for
the boot signal. Attach mode (`driver: log`) disables that wait automatically in
1.1+.

Roblox keeps its active log locked, so you cannot append to it. Test with a
separate file in the same folder instead - OpenCW follows the newest `*.log`:

```powershell
$test = "$env:LOCALAPPDATA\Roblox\logs\opencw-test.log"
Set-Content $test "[FLog::CreatorOutput] ocw::Log-Line test"
Start-Sleep 2
Remove-Item $test
```

You should see:

```text
reading ...opencw-test.log
SITE  ... ocw::Log-Line test
CMD   log-line <- test
USER  test
```

After the file is removed, OpenCW returns to the real log and skips its history.
If that works, the bridge is fine and the page simply is not printing a command
yet.

**Commands are detected but nothing is typed.** Run `python -m opencw doctor`;
`pyautogui` must be importable. On Linux, confirm you are in an X11 session. On
Windows, make sure the client is not running as administrator while OpenCW is
not.

**Replies land in the wrong place.** The address bar offset is wrong. Position
the window with `viewport.*`, then adjust `address-x`/`address-y` by a few
pixels. `setup-delay-ms` may also need to be higher on a slow machine.

**A tab is skipped.** CatWeb only keeps nine tabs open.

**No window backend.** OpenCW still works; the window is simply not moved and
the address offsets become absolute screen coordinates. `pywinctl` (Linux) and
`PyGetWindow` (Windows, installed with pyautogui) both count as backends.
