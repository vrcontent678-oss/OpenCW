"""OpenCW demo script.

Run it from the OpenCW folder:

    python demo.py

A CatWeb page talks to this script by printing lines such as::

    ocw::Ping hello from the hub
    ocw::Log-Line just a message
    ocw::Status
    ocw::Tabs
    ocw::Help

Returning a string navigates the tab that sent the command there.
Returning None leaves the page where it is.
"""

from __future__ import annotations

import opencw


@opencw.command("Ping")
def ping(payload: str) -> str:
    """ocw::Ping <text> -> log the text and open the hub page."""
    opencw.say(f"ping: {payload or '(no payload)'}")
    return "hub.opencw.rbx"


@opencw.command("Log-Line")
def log_line(payload: str) -> None:
    """ocw::Log-Line <text> -> print the text locally, stay on the page."""
    opencw.say(payload or "(empty line)")


@opencw.command("Status")
def status() -> str:
    """ocw::Status -> report tab and command counts, then open the hub."""
    open_tabs = opencw.tabs()
    listing = ", ".join(
        f"{index}={domain}" for index, domain in sorted(open_tabs.items())
    )
    opencw.say(f"{len(open_tabs)} tab(s): {listing or 'none'}")
    return (
        f"hub.opencw.rbx?tabs={len(open_tabs)}"
        f"&commands={len(opencw.commands())}"
    )


@opencw.command("Tabs")
def list_tabs() -> None:
    """ocw::Tabs -> print the open tab map locally, no reply."""
    known = opencw.tabs()
    if not known:
        opencw.say("no tabs have been opened yet")
        return
    for index, domain in sorted(known.items()):
        opencw.say(f"tab {index}: {domain}")


@opencw.command("Help")
def help_command() -> str:
    """ocw::Help -> list every bound command, then open the hub."""
    names = ", ".join(sorted(opencw.commands()))
    opencw.say(f"available commands: {names}")
    return "hub.opencw.rbx?help=1"


if __name__ == "__main__":
    opencw.start()
