"""OpenCW (OpenCatWeb) - drive CatWeb pages from Python."""

from __future__ import annotations

from .mod import config, errors, host, logsource, respond, session, window
from .mod.console import log_sys, log_user

version = "1.1.2"
__version__ = version

# Registration
command = session.command
commands = session.registry

# Lifecycle
start = session.start

# Logging
say = log_user
status = log_sys

# Replies
push = respond.push
tab_of = respond.index_of
tabs = respond.describe

# Settings
set = config.put
settings = config.all

__all__ = [
    "command",
    "commands",
    "start",
    "say",
    "status",
    "push",
    "tab_of",
    "tabs",
    "set",
    "settings",
    "version",
    "config",
    "errors",
    "host",
    "logsource",
    "respond",
    "session",
    "window",
]
