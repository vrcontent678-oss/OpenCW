"""Command line helpers: ``python -m opencw doctor`` and ``python -m opencw logs``."""

from __future__ import annotations

import argparse
import sys


def _doctor() -> int:
    from . import __version__, config, host, session, window

    host.reload()

    print(f"OpenCW {__version__}")
    print(f"python  : {sys.version.split()[0]} ({sys.platform})")
    print(f"platform: {host.describe()}")
    print(f"config  : {config.path()}")
    print(f"driver  : {config.get('client.driver')}")
    print(f"commands: {', '.join(sorted(session.registry())) or '(none)'}")

    for module in ("yaml", "pyautogui", "pyperclip"):
        try:
            __import__(module)
            print(f"{module:<8}: ok")
        except Exception as exc:
            print(f"{module:<8}: missing ({exc})")

    print(f"window  : {window.backend()}")
    if window.available():
        found = window.find(config.get("client.window-title", "auto"), 0.5, announce=False)
        print(f"client  : {window.title() if found else 'not running'}")
    return 0


def _logs(limit: int = 25) -> int:
    """Print the tail of the newest log file (handy for finding the marker)."""
    import glob
    import os

    from . import config

    pattern = str(config.get("client.log-glob") or "").strip()
    if not pattern:
        print("client.log-glob is empty")
        return 1

    expanded = os.path.expandvars(os.path.expanduser(pattern))
    files = [name for name in glob.glob(expanded) if os.path.isfile(name)]
    if not files:
        print(f"no files match {expanded}")
        return 1

    newest = max(files, key=os.path.getmtime)
    print(f"newest: {newest}\n")
    try:
        with open(newest, "r", encoding="utf-8", errors="replace") as handle:
            lines = handle.readlines()[-max(1, limit):]
    except OSError as exc:
        print(f"could not read the file: {exc}")
        return 1

    for line in lines:
        print(line.rstrip())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="opencw")
    parser.add_argument(
        "action",
        nargs="?",
        default="doctor",
        choices=("doctor", "logs", "version"),
    )
    args = parser.parse_args(argv)

    if args.action == "version":
        from . import __version__

        print(__version__)
        return 0

    if args.action == "logs":
        return _logs()

    # Importing the package loads config.yaml, which is what doctor reports on.
    return _doctor()


if __name__ == "__main__":
    raise SystemExit(main())
