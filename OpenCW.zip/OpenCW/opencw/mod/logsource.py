"""Sources that produce the game client's console lines.

Three drivers are available:

``sober``    launch Sober through Flatpak and read its stdout (Linux).
``command``  launch any program and read its stdout.
``log``      tail the newest file matching a glob (works with the Windows client).
"""

from __future__ import annotations

import glob
import os
import shlex
import shutil
import subprocess
import time
from typing import Iterator, Sequence

from . import config, host
from .console import log_sys, log_warn
from .errors import ClientNotFoundError, OpenCWError, SourceError

__all__ = ["Source", "ProcessSource", "LogFileSource", "make_source"]


class Source:
    """A stream of console lines."""

    label = "source"
    kind = "source"

    def stream(self) -> Iterator[str]:
        raise NotImplementedError

    def close(self) -> None:
        pass


class ProcessSource(Source):
    """Reads stdout of a child process."""

    kind = "process"

    def __init__(self, argv: Sequence[str], label: str = "process") -> None:
        self.argv = [str(part) for part in argv]
        self.label = label
        self._proc: subprocess.Popen[str] | None = None

    def start(self) -> None:
        log_sys("launching: " + " ".join(self.argv))
        try:
            self._proc = subprocess.Popen(
                self.argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
        except FileNotFoundError as exc:
            raise ClientNotFoundError(
                f"could not run {self.argv[0]!r} - is it installed and on PATH?"
            ) from exc
        except OSError as exc:
            raise SourceError(f"could not launch {self.argv[0]!r}: {exc}") from exc

    def stream(self) -> Iterator[str]:
        if self._proc is None or self._proc.stdout is None:
            raise SourceError("ProcessSource.start() was never called")
        for line in self._proc.stdout:
            yield line.rstrip("\r\n")

    def close(self) -> None:
        proc = self._proc
        if proc is None or proc.poll() is not None:
            return
        try:
            proc.terminate()
            proc.wait(timeout=3)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass


class LogFileSource(Source):
    """Follows the newest file matching a glob, surviving rotations."""

    kind = "log"

    def __init__(self, pattern: str, poll: float = 0.25) -> None:
        self.pattern = pattern
        self.poll = max(0.05, float(poll))
        self.label = f"log:{pattern}"
        self._handle = None
        self._path: str | None = None
        self._started = time.time()

    # -- file discovery ---------------------------------------------------- #

    def _newest(self) -> str | None:
        expanded = os.path.expandvars(os.path.expanduser(self.pattern))
        try:
            matches = [name for name in glob.glob(expanded) if os.path.isfile(name)]
        except OSError:
            return None
        if not matches:
            return None
        try:
            return max(matches, key=os.path.getmtime)
        except OSError:
            return None

    # -- stream ------------------------------------------------------------ #

    def stream(self) -> Iterator[str]:
        log_sys(f"tailing {self.pattern}")

        announced = False
        while self._newest() is None:
            if not announced:
                log_warn("no log file yet - waiting for the client to start")
                announced = True
            time.sleep(self.poll)

        while True:
            self._rotate_if_needed()
            line = self._readline()
            if line is None:
                time.sleep(self.poll)
                continue
            yield line

    def close(self) -> None:
        self._close_handle()

    # -- internals --------------------------------------------------------- #

    def _rotate_if_needed(self) -> None:
        newest = self._newest()
        if newest and newest != self._path:
            self._open(newest)

    def _open(self, file: str) -> None:
        self._close_handle()
        try:
            handle = open(file, "r", encoding="utf-8", errors="replace")
        except OSError as exc:
            log_warn(f"cannot read {file}: {exc}")
            return

        # Skip history for files that already existed when OpenCW started.
        # A file created afterwards is new, so its first lines are interesting.
        try:
            created = os.path.getctime(file)
        except OSError:
            created = 0.0
        at_end = created < self._started

        if at_end:
            try:
                handle.seek(0, os.SEEK_END)
                handle.readline()  # drop a possibly partial line
            except OSError:
                pass

        self._handle = handle
        self._path = file
        log_sys(f"reading {file}" + (" (history skipped)" if at_end else ""))

    def _close_handle(self) -> None:
        if self._handle is not None:
            try:
                self._handle.close()
            except Exception:
                pass
        self._handle = None

    def _readline(self) -> str | None:
        if self._handle is None:
            return None

        try:
            line = self._handle.readline()
        except (OSError, ValueError):
            self._close_handle()
            return None

        if line:
            return line.rstrip("\r\n")

        # The file may have been truncated in place.
        if self._path:
            try:
                if self._handle.tell() > os.path.getsize(self._path):
                    self._handle.seek(0)
            except OSError:
                pass
        return None


# --------------------------------------------------------------------------- #
# Driver selection
# --------------------------------------------------------------------------- #

def _default_driver() -> str:
    if host.is_linux():
        return "sober"
    if config.get("client.log-glob") or host.default_log_glob():
        return "log"
    if config.get("client.command"):
        return "command"
    raise OpenCWError(
        "no usable driver: install Flatpak and Sober, or set client.log-glob "
        "or client.command in config.yaml"
    )


def _sober_source() -> ProcessSource:
    if shutil.which("flatpak") is None:
        raise ClientNotFoundError(
            "Flatpak was not found - the Linux script set needs Flatpak and "
            "Sober. Set LINUX?: no in opencw/config.txt to use the Windows "
            "script set instead."
        )

    flatpak = str(config.get("client.flatpak", "org.vinegarhq.Sober"))
    place = str(config.get("client.place-id", "16855862021"))
    boot = str(config.get("client.boot-domain", ""))
    uri = f"roblox://placeId={place}\\&launchData={boot}"
    return ProcessSource(["flatpak", "run", flatpak, uri], label="sober")


def _command_source() -> ProcessSource:
    raw = config.get("client.command")
    if not raw:
        raise OpenCWError("client.command is empty")

    if isinstance(raw, str):
        argv = shlex.split(raw)
    else:
        argv = [str(part) for part in raw]

    if not argv:
        raise OpenCWError("client.command does not contain an executable")
    return ProcessSource(argv, label="command")


def _log_source() -> LogFileSource:
    pattern = str(config.get("client.log-glob") or "").strip() or host.default_log_glob()
    if not pattern:
        raise OpenCWError("client.log-glob is empty")

    expanded = os.path.expandvars(os.path.expanduser(pattern))
    directory = os.path.dirname(expanded)
    if directory and not glob.has_magic(directory) and not os.path.isdir(directory):
        raise ClientNotFoundError(
            f"log directory not found: {directory} - start the client once, "
            "or correct client.log-glob"
        )

    poll = float(config.get("client.log-poll-seconds", 0.25) or 0.25)
    return LogFileSource(pattern, poll=poll)


def make_source() -> Source:
    driver = str(config.get("client.driver", "auto") or "auto").strip().lower()
    if driver == "auto":
        driver = _default_driver()

    if driver == "sober":
        source: Source = _sober_source()
    elif driver == "command":
        source = _command_source()
    elif driver == "log":
        source = _log_source()
    else:
        raise OpenCWError(
            f"unknown client.driver {driver!r} (expected auto, sober, command or log)"
        )

    log_sys(f"driver: {driver}")
    if isinstance(source, ProcessSource):
        source.start()
    return source
