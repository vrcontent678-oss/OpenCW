"""Window lookup and placement.

OpenCW keeps track of the game window so that synthetic clicks use coordinates
relative to it instead of hard-coded screen positions.
"""

from __future__ import annotations

import time
from typing import Any, Iterable

from . import host
from .console import log_warn

_backend = None
_backend_name = "none"

try:  # preferred on Linux and macOS
    import pywinctl as _backend  # type: ignore[no-redef]

    _backend_name = "pywinctl"
except Exception:  # pragma: no cover - depends on the environment
    try:  # ships with pyautogui on Windows
        import pygetwindow as _backend  # type: ignore[no-redef]

        _backend_name = "pygetwindow"
    except Exception:
        _backend = None

__all__ = [
    "available",
    "backend",
    "find",
    "place",
    "origin",
    "active",
    "title",
]

_active: Any = None
_origin: tuple[int, int] = (0, 0)


def available() -> bool:
    return _backend is not None


def backend() -> str:
    """Which window library is in use (``pywinctl``, ``pygetwindow`` or ``none``)."""
    return _backend_name


def _candidates(title: Any) -> Iterable[str]:
    if isinstance(title, (list, tuple)):
        return [str(item) for item in title]
    text = str(title or "").strip()
    if not text or text.lower() == "auto":
        return host.window_titles()
    return [text]


def find(
    title: Any = "auto",
    timeout: float = 180.0,
    interval: float = 0.5,
    announce: bool = True,
) -> Any:
    """Wait for a window matching *title* and return it, or ``None``."""
    if _backend is None:
        return None

    deadline = time.time() + max(0.0, float(timeout))
    announced = False

    while True:
        for candidate in _candidates(title):
            try:
                matches = _backend.getWindowsWithTitle(candidate)
            except Exception:
                matches = []
            if matches:
                win = _pick(matches, candidate)
                try:
                    win.activate()
                except Exception:
                    pass
                _activate(win)
                return win

        if time.time() >= deadline:
            return None
        if not announced and announce:
            log_warn(f"waiting for the client window ({title})")
            announced = True
        time.sleep(interval)


def _pick(matches: list[Any], candidate: str) -> Any:
    """Prefer an exact title match, otherwise take the first window."""
    for win in matches:
        try:
            if str(win.title).strip().lower() == candidate.strip().lower():
                return win
        except Exception:
            continue
    return matches[0]


def place(win: Any, x: int, y: int, width: int, height: int) -> None:
    """Move and resize the client window."""
    try:
        if getattr(win, "isMaximized", False):
            win.restore()
    except Exception:
        pass

    try:
        win.moveTo(int(x), int(y))
    except Exception as exc:
        log_warn(f"could not move the client window: {exc}")

    try:
        win.resizeTo(int(width), int(height))
    except Exception as exc:
        log_warn(f"could not resize the client window: {exc}")

    _activate(win)
    time.sleep(0.2)


def origin() -> tuple[int, int]:
    """Top-left corner of the tracked window, in screen pixels."""
    _refresh_origin()
    return _origin


def active() -> Any:
    return _active


def title() -> str:
    if _active is None:
        return ""
    try:
        return str(_active.title)
    except Exception:
        return ""


def _activate(win: Any) -> None:
    global _active
    _active = win
    _refresh_origin()


def _refresh_origin() -> None:
    global _origin
    if _active is None:
        _origin = (0, 0)
        return

    left: int | None = None
    top: int | None = None

    box = getattr(_active, "box", None)
    if box is not None:
        try:
            left, top = int(box.left), int(box.top)
        except Exception:
            try:
                left, top = int(box[0]), int(box[1])
            except Exception:
                left = top = None

    if left is None:
        try:
            left, top = int(_active.left), int(_active.top)
        except Exception:
            return

    _origin = (left, top)
