"""Internal building blocks of OpenCW."""
