"""Keyboard and mouse automation for CatWeb's in-game browser.

Replies are pasted into the address bar of a tab and confirmed with Enter, which
is how a CatWeb page receives data back from Python.
"""

from __future__ import annotations

import time
from threading import RLock
from typing import Iterable

from . import config, window
from .console import log_warn
from .errors import MissingDependencyError

__all__ = [
    "open_tabs",
    "focus",
    "navigate",
    "push",
    "nudge",
    "index_of",
    "describe",
    "reset",
]

_lock = RLock()
_tabs: dict[int, str] = {}
_open = 0
_current = 0


# --------------------------------------------------------------------------- #
# Dependency helpers
# --------------------------------------------------------------------------- #

def _gui():
    try:
        import pyautogui
    except Exception as exc:
        raise MissingDependencyError(
            f"pyautogui is required for replies and tab control ({exc})"
        ) from exc
    pyautogui.PAUSE = 0
    return pyautogui


def _clipboard():
    try:
        import pyperclip
    except Exception:
        return None
    return pyperclip


def _key_delay() -> float:
    return float(config.get("viewport.key-delay-ms", 40) or 0) / 1000.0


def _setup_delay() -> float:
    return float(config.get("viewport.setup-delay-ms", 320) or 0) / 1000.0


# --------------------------------------------------------------------------- #
# Primitives
# --------------------------------------------------------------------------- #

def _address_point() -> tuple[int, int]:
    offset_x = int(config.get("viewport.address-x", 10) or 0)
    offset_y = int(config.get("viewport.address-y", 205) or 0)

    if window.active() is None:
        # No tracked window: treat the offsets as absolute screen pixels.
        return offset_x, offset_y

    origin_x, origin_y = window.origin()
    return origin_x + offset_x, origin_y + offset_y


def _click_address() -> None:
    x, y = _address_point()
    _gui().click(int(x), int(y))
    time.sleep(_key_delay())


def _press(key: str) -> None:
    _gui().press(key)
    time.sleep(_key_delay())


def _hotkey(*keys: str) -> None:
    _gui().hotkey(*keys)
    time.sleep(_key_delay())


def _write(text: str) -> None:
    gui = _gui()
    text = str(text)

    board = _clipboard()
    if board is not None:
        try:
            board.copy(text)
            gui.hotkey("ctrl", "v")
            time.sleep(_key_delay())
            return
        except Exception:
            pass

    # Clipboard-less fallback (ASCII only).
    gui.write(text, interval=0.01)
    time.sleep(_key_delay())


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

def open_tabs(domains: Iterable[str]) -> dict[int, str]:
    """Replace the current tabs with one per domain and return the mapping."""
    global _tabs, _open, _current

    names = [str(domain).strip() for domain in domains if str(domain).strip()]

    with _lock:
        _gui()  # fail early if automation is unavailable

        _click_address()
        time.sleep(_setup_delay())

        # Close the boot page and the spare tab CatWeb opens with it.
        _hotkey("ctrl", "w")
        time.sleep(_setup_delay())
        _hotkey("ctrl", "w")
        time.sleep(_setup_delay())

        _tabs = {}
        _open = 0

        for domain in names:
            if _open >= 9:
                log_warn("CatWeb keeps at most 9 tabs open; ignoring the rest")
                break

            if _open:
                _hotkey("ctrl", "t")
                time.sleep(_setup_delay())
            else:
                _click_address()
                time.sleep(_setup_delay())

            _write(domain)
            time.sleep(_setup_delay())
            _press("enter")
            time.sleep(_setup_delay())

            _open += 1
            _tabs[_open] = domain

        _current = _open
        return dict(_tabs)


def focus(index: int) -> None:
    """Bring tab *index* (1-based) to the front."""
    with _lock:
        _focus_locked(int(index))


def _focus_locked(index: int) -> None:
    global _current
    if not (0 < index <= _open) or index == _current:
        return
    _gui().hotkey("ctrl", str(index))
    _current = index
    time.sleep(_key_delay())


def navigate(value: str) -> None:
    """Type *value* into the current tab's address bar and press Enter."""
    with _lock:
        _navigate_locked(value)


def _navigate_locked(value: str) -> None:
    _click_address()
    time.sleep(_setup_delay())
    _write(str(value))
    time.sleep(_key_delay())
    _press("enter")
    time.sleep(_key_delay())


def push(tab: int, value: str) -> None:
    """Focus *tab* (if needed) and send *value* to its address bar."""
    with _lock:
        _focus_locked(int(tab or 0))
        _navigate_locked(value)


def nudge() -> None:
    """Two Escape presses keep the client from idling out."""
    with _lock:
        _press("esc")
        time.sleep(_key_delay())
        _press("esc")


def index_of(domain: str) -> int:
    """Tab number currently showing *domain*, or 0 when unknown."""
    for index, name in _tabs.items():
        if name == domain:
            return index
    return 0


def describe() -> dict[int, str]:
    return dict(_tabs)


def reset() -> None:
    global _tabs, _open, _current
    with _lock:
        _tabs = {}
        _open = 0
        _current = 0
