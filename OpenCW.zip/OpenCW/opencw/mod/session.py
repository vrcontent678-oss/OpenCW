"""Command registry and the main OpenCW loop."""

from __future__ import annotations

import inspect
import re
import time
from concurrent.futures import ThreadPoolExecutor
from queue import Empty, Queue
from threading import Event, Thread
from typing import Any, Callable

from . import config, host, logsource, respond, window
from .console import (
    log_cmd,
    log_err,
    log_game,
    log_site,
    log_sys,
    log_warn,
    set_colour,
    set_enabled,
)
from .errors import OpenCWError

__all__ = ["command", "registry", "start"]

_registry: dict[str, Callable[..., Any]] = {}


# --------------------------------------------------------------------------- #
# Registration
# --------------------------------------------------------------------------- #

def command(name: Any = None) -> Callable:
    """Bind a function to a CatWeb command.

    @opencw.command("Ping")
    def ping(payload: str):
        ...
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        key = str(name or func.__name__).strip().lower()
        if not key:
            raise ValueError("command names cannot be empty")
        if key in _registry:
            raise ValueError(f"command '{key}' is already bound")
        _registry[key] = func
        return func

    # Bare @opencw.command without parentheses.
    if callable(name):
        func = name
        name = None
        return decorator(func)

    return decorator


def registry() -> dict[str, Callable[..., Any]]:
    return dict(_registry)


# --------------------------------------------------------------------------- #
# Dispatch helpers
# --------------------------------------------------------------------------- #

def _wants_payload(func: Callable[..., Any]) -> bool:
    try:
        params = list(inspect.signature(func).parameters.values())
    except (TypeError, ValueError):
        return True
    return any(
        param.kind
        in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        )
        for param in params
    )


def _invoke(func: Callable[..., Any], payload: str) -> Any:
    return func(payload) if _wants_payload(func) else func()


def _stringify(result: Any) -> str | None:
    if result is None:
        return None
    if isinstance(result, bytes):
        result = result.decode("utf-8", "replace")
    text = result if isinstance(result, str) else str(result)
    text = text.strip()
    return text or None


def _reply_target(origin: str | None) -> int:
    mode = str(config.get("listen.reply-target", "origin") or "origin").lower()
    if mode == "fixed":
        return int(config.get("listen.fixed-tab", 1) or 1)
    if origin:
        for candidate in (origin, origin.split("/", 1)[0]):
            index = respond.index_of(candidate)
            if index:
                return index
    return 0


def _enqueue_reply(future, tab: int, name: str, queue: Queue) -> None:
    try:
        result = future.result()
    except Exception as exc:
        log_err(f"command '{name}' crashed: {type(exc).__name__}: {exc}")
        return

    text = _stringify(result)
    if text is not None:
        queue.put((tab, text))


def _response_worker(queue: Queue, stop: Event) -> None:
    while not stop.is_set() or not queue.empty():
        try:
            tab, text = queue.get(timeout=0.1)
        except Empty:
            continue
        try:
            respond.push(tab, text)
        except Exception as exc:
            log_err(f"could not deliver a reply: {type(exc).__name__}: {exc}")
        finally:
            queue.task_done()


def _truthy(value: Any, default: bool) -> bool:
    """Parse an auto/true/false style config value."""
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("", "auto"):
        return default
    return text in ("1", "true", "yes", "on", "y")


_ORIGIN = re.compile(r"\[From\s+([^\]]+)\]:\s*", re.IGNORECASE)


def _strip_origin(text: str, domains: list[str]) -> tuple[str | None, str]:
    """Split ``example.rbx]: hello`` or ``[From example.rbx/home]: hello``."""
    for domain in domains:
        for pattern in (f"[{domain}]: ", f"{domain}]: "):
            index = text.find(pattern)
            if index >= 0:
                return domain, text[index + len(pattern):].strip()

    # CatWeb pages log through a prefix like ``[From wa.rbx/home]:``.
    match = _ORIGIN.search(text)
    if match:
        return match.group(1).strip(), text[match.end():].strip()

    return None, text


# --------------------------------------------------------------------------- #
# Startup helpers
# --------------------------------------------------------------------------- #

def _preflight() -> None:
    log_sys(f"platform: {host.describe()}")
    problems: list[str] = list(host.preflight_notes())

    try:
        import pyautogui  # noqa: F401
    except Exception as exc:
        problems.append(
            f"pyautogui is unavailable ({exc}); replies and tab control will fail"
        )

    if not window.available():
        problems.append(
            "no window backend found; the client window cannot be positioned "
            "(install pywinctl, or pyautogui on Windows)"
        )

    for problem in problems:
        log_warn(problem)


def _place_window() -> None:
    if not window.available():
        return

    found = window.find(
        config.get("client.window-title", "auto"),
        float(config.get("client.window-timeout", 180) or 0),
    )
    if found is None:
        log_warn(
            "client window not found - viewport.address-x/y are used as absolute "
            "screen coordinates"
        )
        return

    window.place(
        found,
        int(config.get("viewport.position-x", 40) or 0),
        int(config.get("viewport.position-y", 40) or 0),
        int(config.get("viewport.width", 820) or 820),
        int(config.get("viewport.height", 620) or 620),
    )
    log_sys(f"window placed at {window.origin()}")


def _open_tabs(domains: list[str]) -> None:
    if not domains:
        log_warn("client.domains is empty - no tabs will be opened")
        return

    log_sys(f"setting up {len(domains)} tab(s)")
    try:
        tabs = respond.open_tabs(domains)
    except Exception as exc:
        log_err(f"tab setup failed: {type(exc).__name__}: {exc}")
        return

    for index in sorted(tabs):
        log_sys(f"  tab {index}: {tabs[index]}")


# --------------------------------------------------------------------------- #
# Main loop
# --------------------------------------------------------------------------- #

def start(*, quiet: bool = False, driver: str | None = None) -> None:
    """Launch / attach to the client and process commands until Ctrl+C."""
    set_enabled(not quiet)
    set_colour(bool(config.get("logging.colour", True)))

    if driver:
        config.put("client.driver", driver)

    _preflight()

    domains = [
        str(domain) for domain in (config.get("client.domains") or []) if str(domain).strip()
    ]
    marker = str(config.get("listen.marker", "") or "")
    prefix = str(config.get("listen.prefix", "") or "").lower()
    boot_signal = str(config.get("listen.boot-signal", "") or "")
    ignore = [str(value) for value in (config.get("listen.ignore") or [])]
    workers = max(1, int(config.get("listen.workers", 8) or 8))
    idle_seconds = float(config.get("listen.idle-seconds", 0) or 0)
    show_game = bool(config.get("logging.show-game-lines", True))
    show_raw = bool(config.get("logging.show-unmatched", False))

    if not marker:
        raise OpenCWError("listen.marker is empty - no line could ever be detected")

    log_sys(f"bound commands: {', '.join(sorted(_registry)) or '(none)'}")
    if not _registry:
        log_warn("no commands bound - did you forget @opencw.command(...)?")

    source = None
    try:
        source = logsource.make_source()
    except OpenCWError as exc:
        log_err(str(exc))
        return

    _place_window()

    queue: Queue = Queue()
    stop = Event()
    replies = Thread(target=_response_worker, args=(queue, stop), daemon=True)
    replies.start()

    executor = ThreadPoolExecutor(max_workers=workers)

    attach_mode = getattr(source, "kind", "") == "log"
    require_boot = _truthy(config.get("listen.require-boot", "auto"), not attach_mode)
    manage_tabs = _truthy(config.get("listen.manage-tabs", "auto"), not attach_mode)

    booted = not (require_boot and boot_signal)
    if require_boot and not boot_signal:
        log_warn("listen.boot-signal is empty; commands are not gated by it")
    if attach_mode:
        log_sys(
            "attach mode: the client is already running; tabs are "
            + ("managed once the boot signal appears" if manage_tabs else "not reopened")
        )
        if not manage_tabs:
            log_sys("replies go to the focused tab unless listen.reply-target is 'fixed'")
    elif require_boot and boot_signal:
        log_sys(f"waiting for boot signal {boot_signal}")

    last_input = time.time()

    try:
        for raw in source.stream():
            now = time.time()

            if idle_seconds and now - last_input >= idle_seconds:
                last_input = now
                log_sys(f"idle for {int(idle_seconds)}s - poking the client")
                try:
                    respond.nudge()
                except Exception as exc:
                    log_warn(f"anti-idle failed: {exc}")

            if show_raw:
                log_game(raw)

            if marker not in raw:
                continue

            text = raw.split(marker, 1)[1].strip()
            origin, text = _strip_origin(text, domains)

            if not booted:
                if boot_signal and boot_signal in text:
                    booted = True
                    if manage_tabs:
                        _open_tabs(domains)
                elif show_game:
                    log_game(f"(pre-boot) {text}")
                continue

            if origin:
                log_site(text, origin)
            elif show_game and not any(value in text for value in ignore):
                log_game(text)

            if not prefix:
                continue
            position = text.lower().find(prefix)
            if position < 0:
                continue

            body = text[position + len(prefix):].strip()
            if not body:
                continue

            parts = body.split(None, 1)
            name = parts[0].lower()
            payload = parts[1].strip() if len(parts) > 1 else ""

            handler = _registry.get(name)
            if handler is None:
                log_warn(f"no handler for command '{name}'")
                continue

            log_cmd(name, payload)
            target = _reply_target(origin)
            future = executor.submit(_invoke, handler, payload)
            future.add_done_callback(
                lambda done, tab=target, cmd=name: _enqueue_reply(done, tab, cmd, queue)
            )
            last_input = now

    except KeyboardInterrupt:
        log_sys("interrupted - shutting down")
    finally:
        executor.shutdown(wait=True)
        stop.set()
        replies.join(timeout=2.0)
        source.close()
