"""Configuration loading for OpenCW.

The config lives next to the script that imports OpenCW (``config.yaml``).
``OPENCW_CONFIG`` can point somewhere else. If no file exists, the bundled
``config.fallback.yaml`` is copied into the working directory and OpenCW stops
so the user can review it before the first real run.
"""

from __future__ import annotations

import copy
import os
import shutil
from pathlib import Path
from typing import Any, Iterator

from .console import log_err, log_sys, log_warn

try:
    import yaml
except ImportError:  # pragma: no cover - depends on the environment
    raise SystemExit(
        "OpenCW needs PyYAML. Install the requirements first:\n"
        "    python -m pip install -r requirements.txt"
    ) from None

__all__ = ["get", "put", "all", "path", "reload"]

_PACKAGE_ROOT = Path(__file__).resolve().parent.parent
_FALLBACK = _PACKAGE_ROOT / "config.fallback.yaml"

_data: dict[str, Any] = {}
_path: Path | None = None


def _candidates() -> Iterator[Path]:
    override = os.environ.get("OPENCW_CONFIG")
    if override:
        yield Path(override).expanduser()
    yield Path.cwd() / "config.yaml"


def _read(file: Path) -> dict[str, Any]:
    try:
        with file.open("r", encoding="utf-8") as handle:
            loaded = yaml.safe_load(handle)
    except yaml.YAMLError as exc:
        log_err(f"could not parse {file}: {exc}")
        raise SystemExit(3) from None
    except OSError as exc:
        log_err(f"could not read {file}: {exc}")
        raise SystemExit(3) from None

    if loaded is None:
        loaded = {}
    if not isinstance(loaded, dict):
        log_err(f"{file} must contain a mapping at the top level")
        raise SystemExit(3)
    return loaded


def _bootstrap() -> None:
    global _data, _path

    for candidate in _candidates():
        if candidate.is_file():
            _data = _read(candidate)
            _path = candidate
            log_sys(f"config loaded from {candidate}")
            return

    if _FALLBACK.is_file():
        target = Path.cwd() / "config.yaml"
        try:
            shutil.copyfile(_FALLBACK, target)
        except OSError as exc:
            log_err(f"no config.yaml and the fallback could not be copied: {exc}")
            raise SystemExit(2) from None
        log_warn(
            "no config.yaml was found - a fresh one has been written and OpenCW "
            "stopped. Review it, then run again."
        )
        raise SystemExit(1)

    log_err("no config.yaml found and the bundled fallback is missing (broken install)")
    raise SystemExit(2)


_bootstrap()


def get(dotted: str, default: Any = None) -> Any:
    """Read a value using a dotted path, e.g. ``get("viewport.width")``."""
    node: Any = _data
    for key in dotted.split("."):
        if isinstance(node, dict) and key in node:
            node = node[key]
        else:
            return default
    return node


def put(dotted: str, value: Any) -> Any:
    """Set a value for this process only. Never rewrites the YAML file."""
    keys = dotted.split(".")
    node = _data
    for key in keys[:-1]:
        child = node.get(key)
        if not isinstance(child, dict):
            child = {}
            node[key] = child
        node = child
    node[keys[-1]] = value
    return value


def all() -> dict[str, Any]:
    """A deep copy of the active configuration."""
    return copy.deepcopy(_data)


def path() -> Path | None:
    """Where the configuration was loaded from."""
    return _path


def reload() -> None:
    """Re-read the file that was originally loaded."""
    global _data
    if _path is not None and _path.is_file():
        _data = _read(_path)
