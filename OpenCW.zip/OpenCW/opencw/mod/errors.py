"""Exception types used by OpenCW."""

from __future__ import annotations


class OpenCWError(Exception):
    """Base class for every OpenCW problem."""


class MissingDependencyError(OpenCWError):
    """A required third-party package is not installed."""


class ClientNotFoundError(OpenCWError):
    """The game client could not be launched or located."""


class SourceError(OpenCWError):
    """The console stream could not be opened."""
