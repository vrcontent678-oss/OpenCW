"""Platform switch.

OpenCW reads ``opencw/config.txt`` and decides which platform scripts to use::

    LINUX?: yes    # Flatpak + Sober, stdout console stream
    LINUX?: no     # Roblox client, newest log file
    LINUX?: auto   # detect from the operating system

The value is read once, the first time it is needed. ``reload()`` re-reads the
file (used by tests and by ``python -m opencw doctor``).
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path

from .console import log_warn

__all__ = [
    "LINUX",
    "WINDOWS",
    "mode",
    "script_set",
    "is_linux",
    "is_windows",
    "source",
    "describe",
    "reload",
    "window_titles",
    "default_driver",
    "default_log_glob",
    "preflight_notes",
]

LINUX = "linux"
WINDOWS = "windows"

#: ``opencw/config.txt`` - lives beside ``__init__.py`` inside the package.
FILE = Path(__file__).resolve().parent.parent / "config.txt"

_YES = {"yes", "y", "true", "1", "on", "linux"}
_NO = {"no", "n", "false", "0", "off", "windows"}
_AUTO = {"", "auto", "detect", "default"}

_LINE = re.compile(r"^\s*linux\s*\??\s*[:=]?\s*(\S+)\s*$", re.IGNORECASE)

_mode: str | None = None
_source = "auto-detection"


def _detected() -> str:
    return LINUX if sys.platform.startswith("linux") else WINDOWS


def _load() -> None:
    global _mode, _source

    _mode = None
    _source = "auto-detection"

    if not FILE.is_file():
        _mode = _detected()
        _source = "auto-detection (opencw/config.txt missing)"
        return

    try:
        text = FILE.read_text(encoding="utf-8-sig")
    except OSError as exc:
        log_warn(f"could not read {FILE}: {exc}")
        _mode = _detected()
        _source = "auto-detection (config.txt unreadable)"
        return

    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue

        match = _LINE.match(line)
        if not match:
            continue

        value = match.group(1).strip().strip("\"'").lower()

        if value in _AUTO:
            _mode = _detected()
            _source = f"{FILE} (auto)"
            return
        if value in _YES:
            _mode = LINUX
            _source = str(FILE)
            return
        if value in _NO:
            _mode = WINDOWS
            _source = str(FILE)
            return

        log_warn(f"{FILE}: unknown LINUX? value {value!r} - auto-detecting instead")
        break

    _mode = _detected()
    _source = f"{FILE} (auto)"


def reload() -> None:
    """Re-read ``config.txt`` (mainly useful for tests)."""
    _load()


def mode() -> str:
    if _mode is None:
        _load()
    return _mode or _detected()


def script_set() -> str:
    """Which script set is active: ``"linux"`` or ``"windows"``."""
    return mode()


def is_linux() -> bool:
    return mode() == LINUX


def is_windows() -> bool:
    return mode() == WINDOWS


def source() -> str:
    """Where the decision came from (config.txt or auto-detection)."""
    if _mode is None:
        _load()
    return _source


def describe() -> str:
    return f"{script_set()} scripts ({source()})"


# --------------------------------------------------------------------------- #
# Per-platform defaults
# --------------------------------------------------------------------------- #

def window_titles() -> tuple[str, ...]:
    """Window titles to look for, most specific first."""
    if is_linux():
        return ("Sober", "Roblox")
    return ("Roblox", "Roblox Player", "Sober")


def default_driver() -> str:
    """Driver used when ``client.driver`` is ``auto``."""
    return "sober" if is_linux() else "log"


def default_log_glob() -> str:
    """Fallback log pattern for the Windows script set."""
    if is_windows():
        return r"%LOCALAPPDATA%\Roblox\logs\*.log"
    return ""


def preflight_notes() -> list[str]:
    """Platform-specific warnings for the startup check."""
    notes: list[str] = []

    if is_linux():
        if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            notes.append(
                "no DISPLAY or WAYLAND_DISPLAY found; automation needs a desktop session"
            )
        elif os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland":
            notes.append(
                "Wayland detected; synthetic input may not reach the client (X11 is safer)"
            )
    elif sys.platform.startswith("linux"):
        notes.append(
            "config.txt selects the Windows scripts on a Linux host; the log "
            "driver expects Windows paths"
        )

    return notes
