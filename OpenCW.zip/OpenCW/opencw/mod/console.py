"""Console output helpers for OpenCW.

Every log function is thread-safe and never raises.
"""

from __future__ import annotations

import ctypes
import os
import sys
import threading
from pathlib import Path

__all__ = [
    "log_sys",
    "log_cmd",
    "log_site",
    "log_game",
    "log_user",
    "log_warn",
    "log_err",
    "set_enabled",
    "set_colour",
]

_ENABLED = True
_COLOUR = True
_LOCK = threading.Lock()

_COLOURS = {
    "SYS": 33,
    "CMD": 40,
    "SITE": 45,
    "GAME": 240,
    "USER": 214,
    "WARN": 220,
    "ERR": 160,
}


def _enable_windows_ansi() -> None:
    """Ask the Windows console to interpret ANSI escape sequences."""
    if os.name != "nt":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


_enable_windows_ansi()


def set_enabled(flag: bool) -> None:
    global _ENABLED
    _ENABLED = bool(flag)


def set_colour(flag: bool) -> None:
    global _COLOUR
    _COLOUR = bool(flag)


def _caller() -> str:
    """Name of the module that called a log function."""
    try:
        return Path(sys._getframe(2).f_code.co_filename).stem
    except Exception:
        return ""


def _emit(tag: str, message: str, caller: str = "") -> None:
    if not _ENABLED:
        return
    text = f"{caller.upper()}: {message}" if caller else str(message)
    colour = _COLOURS.get(tag, 250)
    with _LOCK:
        if _COLOUR:
            prefix = f"\033[48;5;{colour}m\033[38;5;0m {tag:<4} \033[0m"
            tint = 250 if colour == 240 else colour
            print(f"{prefix} \033[38;5;{tint}m{text}\033[0m", flush=True)
        else:
            print(f"[{tag}] {text}", flush=True)


def log_sys(message: object) -> None:
    _emit("SYS", str(message), _caller())


def log_cmd(name: str, payload: str = "") -> None:
    _emit("CMD", f"{name} <- {payload}" if payload else name)


def log_site(message: object, origin: str) -> None:
    _emit("SITE", f"[{origin}] {message}")


def log_game(message: object) -> None:
    _emit("GAME", str(message))


def log_user(message: object) -> None:
    _emit("USER", str(message), _caller())


def log_warn(message: object) -> None:
    _emit("WARN", str(message), _caller())


def log_err(message: object) -> None:
    _emit("ERR", str(message), _caller())
