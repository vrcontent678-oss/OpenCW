import opencw


@opencw.command("Ping")
def ping(payload: str):
    """ocw::Ping <text>  ->  logs the text and opens the hub page."""
    opencw.say(f"ping from the site: {payload!r}")
    return "hub.opencw.rbx"


@opencw.command("Log-Line")
def log_line(payload: str):
    """ocw::Log-Line <text>  ->  prints <text> here and stays on the page."""
    opencw.say(payload)


@opencw.command("Status")
def status():
    """ocw::Status  ->  answers with a small summary page."""
    bound = len(opencw.commands())
    return f"hub.opencw.rbx?commands={bound}"


opencw.start()
